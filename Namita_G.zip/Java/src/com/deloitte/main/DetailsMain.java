package com.deloitte.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.deloitte.dao.Movie;



public class DetailsMain {
	

	public static void main(String[] args) {
		new DetailsMain();
		//Scanner sc=new Scanner(System.in);
		//int idInp=sc.nextInt();
		List<Movie> mDetails=new ArrayList<>();
		mDetails.add(new Movie(123,"Marjaavan","12/01/2020","18:30","booked"));
		mDetails.add(new Movie(122,"Hey Baby","13/01/2020","19:30","available"));
		mDetails.add(new Movie(124,"Good news","14/01/2020","16:30","booked"));
		System.out.println(mDetails);
		
	}
}
