package com.deloitte.main;

public interface MovieInfo {

}
